#include "myclass.h"

MyClass::MyClass(QObject *parent) : QObject(parent)
{

}
